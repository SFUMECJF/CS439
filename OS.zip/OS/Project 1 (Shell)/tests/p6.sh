#!/bin/bash
echo "hello world on stdout"
>&2 echo "hello world on stderr"